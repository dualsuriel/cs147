const Images = {
  school1: require('../Images/school1.png'),
  park: require('../Images/park.png'),
  city: require('../Images/city.png'),
  desk: require('../Images/desk.png'),
  dad: require('../Images/dad.png'),
  mom: require('../Images/mom.png'),
  aunt: require('../Images/aunt.png'),
  uncle: require('../Images/uncle.png'),
  happy: require('../Images/happy.png'),
  sad: require('../Images/sad.png'),
  mad: require('../Images/mad.png'),
  idea: require('../Images/idea.png'),
}

export default Images;
